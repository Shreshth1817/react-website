export const PFE = require('./App_ui.png');
export const FoodDelivey = require('./App_ui.png');
export const OnlineStore = require('./App_ui.png');
export const CarRental = require('./App_ui.png');